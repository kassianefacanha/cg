#ifndef TV_H
#define TV_H

#include <objeto.h>

class Tv : public Objeto
{
public:
    Tv();
    void desenha();
};

#endif // TV_H
