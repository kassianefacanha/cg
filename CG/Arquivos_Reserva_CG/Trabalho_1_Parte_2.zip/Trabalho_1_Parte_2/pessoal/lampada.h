#ifndef LAMPADA_H
#define LAMPADA_H

#include <objeto.h>

class Lampada : public Objeto
{
public:
    Lampada();
    void desenha();
};

#endif // LAMPADA_H
