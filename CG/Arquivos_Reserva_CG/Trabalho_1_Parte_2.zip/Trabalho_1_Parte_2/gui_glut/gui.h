#ifndef GUI_H
#define GUI_H

typedef void (* displayFunction)( void );
typedef void (* keyFunction)( unsigned char, int, int );

#include "extra.h"
#include "model3ds.h"

class GUI {
    private:
        int id;
        const char *wTitle; //window title
        int wWidth, wHeight; //window dimensions
        displayFunction display;
        keyFunction key;

    public:
        GUI( int width, int height, displayFunction dFunction = glutGUI::defaultDisplay, keyFunction kFunction = glutGUI::defaultKey, const char *title = "GLUT" );
        void GLUTInit();
        void GLInit();
        ~GUI();

        void setTitle(const char *title);
        void setDimensions(int width, int height);
        void setDisplay( displayFunction dFunction );
        void setKey( keyFunction kFunction );

        static void displayInit();
        static void displayEnd();
        static void keyInit(unsigned char key, int x, int y);
        static void setLight(int id, float posx, float posy, float posz, bool onOffKeyDefault = false, bool attenuated = true, bool low = false, bool hidden = false, bool pontual = true, bool spot = false, bool onOffUserControl = true);
        static void setColor(float r, float g, float b, float a = 1.0, bool specular = false);
        static void glShearXf(float shY, float shZ); //Y e Z fixos
        static void glShearYf(float shX, float shZ); //X e Z fixos
        static void glShearZf(float shX, float shY); //X e Y fixos
        static void glShearXYf(float shX, float shY); //Z fixo
        static void glShearXZf(float shX, float shZ); //Y fixo
        static void glShearYZf(float shY, float shZ); //X fixo
        static void glReflectPlaneYZf(); //inverte sinal de X
        static void glReflectPlaneXZf(); //inverte sinal de Y
        static void glReflectPlaneXYf(); //inverte sinal de Z
        //-------------------sombra-------------------
        static void shadowMatrixYk(GLfloat shadowMat[4][4], GLfloat lightpos[4], GLfloat k);
        static void shadowMatrix(GLfloat shadowMat[4][4], GLfloat groundplane[4], GLfloat lightpos[4]);
        //-------------------sombra-------------------

        static void drawSphere(float x, float y, float z, float radius);
        static void drawQuad(float width = 5.0, float height = 5.0, float discrWidth = 0.3, float discrHeight = 0.3, float texWidth = 5.0, float texHeight = 5.0, bool inverted = false);
        static void drawOriQuad(float angle = 0.0, float ex = 1.0, float ey = 0.0, float ez = 0.0, float width = 5.0, float height = 5.0, float discrWidth = 0.3, float discrHeight = 0.3, float texWidth = 5.0, float texHeight = 5.0, bool inverted = false);
        static void drawQuadBox(float xmin, float ymin, float zmin, float xmax, float ymax, float zmax, float discrWidth = 0.3, float discrHeight = 0.3, bool inverted = false);
        static void drawBox(float xmin, float ymin, float zmin, float xmax, float ymax, float zmax, bool inverted = false);
        static void drawScaledBox(float scale, float xmin, float ymin, float zmin, float xmax, float ymax, float zmax, bool inverted = false);
        static void drawFloor(float width = 5.0, float height = 5.0, float discrWidth = 0.3, float discrHeight = 0.3, float texWidth = 5.0, float texHeight = 5.0);
        static void drawOrigin(float tamanho = 0.1);
        static void drawCamera(float tamanho = 0.5);
        static void draw3ds(Model3DS &model3DS, float tx=0, float ty=0, float tz=0,
                                                float ax=0, float ay=0, float az=0,
                            float sx=1, float sy=1, float sz=1);
};

#endif
